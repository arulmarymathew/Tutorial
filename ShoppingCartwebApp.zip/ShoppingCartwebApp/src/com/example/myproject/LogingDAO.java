package com.example.myproject;

public class LogingDAO 
{
public boolean isValidUser(String userId , String password)
{
	if(userId.equals(password))
	{
		return true;
	}
	else
	{
		return false;
	}
}
}
